import { useState } from 'react'
import { motion } from 'framer-motion'
import {
  PhoneCall, Mic, Sparkles, Globe, ShieldCheck, Zap,
  ArrowRight, BarChart3, MessageSquare,
} from 'lucide-react'

import Typewriter from '@/components/Typewriter'
import DemoCallModal from '@/components/DemoCallModal'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { COMPANY } from '@/config'

const HERO_PHRASES = [
  'real-time voice agents.',
  'multilingual conversations.',
  'outbound sales at scale.',
  'sub-second response times.',
]

const FEATURES = [
  { Icon: PhoneCall,    title: 'Outbound at Scale',     desc: 'Dial thousands of leads in parallel with concurrency + delay controls.' },
  { Icon: Mic,          title: 'Real-Time Streaming',   desc: 'Bidirectional mulaw via Twilio, Plivo and Exotel MediaStreams. ~600 ms turn latency.' },
  { Icon: Globe,        title: '12+ Indian Languages',  desc: 'Hindi, Marathi, Tamil, Telugu, Bengali, Kannada, Gujarati and more — auto-detect mid-call.' },
  { Icon: Sparkles,     title: 'Soft-Hearted AI',       desc: 'Gemini-powered conversations that acknowledge, butter up, and flow naturally.' },
  { Icon: BarChart3,    title: 'Per-Module Cost Track', desc: 'Live breakdown of STT, TTS, LLM and telephony spend on every call.' },
  { Icon: ShieldCheck,  title: 'Enterprise Auth',       desc: 'JWT + bcrypt + role-based access. Multi-tenant from day one.' },
]

export default function LandingPage() {
  const [demoOpen, setDemoOpen] = useState(false)

  return (
    <>
      {/* ── Hero ───────────────────────────────────────────────────────── */}
      <section className="relative overflow-hidden w-full px-4 sm:px-6">
        <div className="pt-8 lg:pt-12 pb-20 lg:pb-28">
          <motion.div
            initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="text-center mx-auto"
          >
            <span className="my-8 inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 text-xs font-medium uppercase tracking-[0.18em] text-[var(--color-fg-muted)]">
              <span className="relative flex h-2 w-2">
                <span className="animate-pulse-ring absolute inline-flex h-full w-full rounded-full bg-[var(--color-accent)]" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-[var(--color-accent)]" />
              </span>
              Voice AI by {COMPANY.name}
            </span>

            {/* Two-line hero — line 1 bold solid, line 2 gradient typewriter (fixed width prevents reflow) */}
            <h1 className="font-display text-4xl sm:text-5xl lg:text-7xl font-bold tracking-tight leading-[1.12]">
              <span className="block whitespace-nowrap text-[var(--color-fg)]">The AI-Powered voice layer for</span>
              <span className="block mb-6 text-gradient-shimmer">
                <Typewriter phrases={HERO_PHRASES} />
              </span>
            </h1>

            <p className="mt-6 mx-auto text-base lg:text-lg leading-relaxed text-[var(--color-fg-muted)] max-w-2xl">
              {COMPANY.name} powers human-grade phone conversations at machine scale.
              Place a free demo call right now — no signup required.
            </p>

            <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
              <Button variant="gradient" size="lg" onClick={() => setDemoOpen(true)}>
                <PhoneCall className="size-4" />
                Try Demo Call
                <ArrowRight className="size-4" />
              </Button>
            </div>

            <p className="mt-6 text-xs text-[var(--color-fg-subtle)]">
              Free demo — 3 calls per email per 24 hours. No card required.
            </p>
          </motion.div>
        </div>
      </section>

      {/* ── Feature bento ─────────────────────────────────────────────── */}
      <section className="relative w-full px-4 sm:px-6 py-20 lg:py-28">
        <div className="text-center mx-auto max-w-2xl mb-14">
          <h2 className="font-display text-3xl sm:text-4xl font-semibold tracking-tight">
            Built for the next generation of enterprise.
          </h2>
          <p className="mt-4 text-base lg:text-lg text-[var(--color-fg-muted)] leading-relaxed">
            Every layer — speech, intent, voice, telephony — engineered for production load.
          </p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 max-w-7xl mx-auto">
          {FEATURES.map(({ Icon, title, desc }, i) => (
            <motion.div
              key={title}
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-80px' }}
              transition={{ duration: 0.45, delay: i * 0.04, ease: [0.16, 1, 0.3, 1] }}
            >
              <Card className="h-full hover:border-[var(--color-accent)] hover:shadow-xl hover:shadow-[var(--color-accent-soft)] transition-all">
                <CardHeader>
                  <div className="mb-3 inline-flex h-11 w-11 items-center justify-center rounded-xl bg-[var(--color-accent-soft)] text-[var(--color-accent)]">
                    <Icon className="size-5" />
                  </div>
                  <CardTitle className="text-lg">{title}</CardTitle>
                  <CardDescription className="text-sm leading-relaxed">{desc}</CardDescription>
                </CardHeader>
              </Card>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ── CTA strip ─────────────────────────────────────────────────── */}
      <section className="relative w-full px-4 sm:px-6 py-20">
        <motion.div
          initial={{ opacity: 0, scale: 0.97 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.5, type: 'spring', stiffness: 200, damping: 24 }}
          className="relative overflow-hidden rounded-3xl glass-strong p-12 lg:p-20 text-center max-w-7xl mx-auto"
        >
          <div className="absolute -top-20 -right-20 size-80 rounded-full bg-[var(--color-accent)] opacity-20 blur-3xl animate-blob-slow" />
          <div className="absolute -bottom-24 -left-20 size-96 rounded-full opacity-20 blur-3xl animate-blob"
               style={{ background: 'var(--gradient-2)' }} />

          <div className="relative">
            <Zap className="size-10 mx-auto mb-4 text-[var(--color-accent)]" />
            <h2 className="font-display text-3xl sm:text-4xl font-semibold tracking-tight">
              Hear it before you buy it.
            </h2>
            <p className="mt-3 text-base lg:text-lg text-[var(--color-fg-muted)] max-w-xl mx-auto">
              One form, one phone number. We'll call you back in under 10 seconds.
            </p>
            <Button variant="gradient" size="lg" onClick={() => setDemoOpen(true)} className="mt-7">
              <MessageSquare className="size-4" />
              Start a Demo Call
            </Button>
          </div>
        </motion.div>
      </section>

      <DemoCallModal open={demoOpen} onOpenChange={setDemoOpen} />
    </>
  )
}
